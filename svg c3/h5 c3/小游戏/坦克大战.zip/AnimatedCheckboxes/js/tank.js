
var dtankarr=[];
$(function  () {
	$(window).data("play",function  () {
	   //��ʼ������
	    init();
	  //��ʼ������
	    initData();
	  /*
	    ���ս���Ļ����Ĳ���Ԫ��
	  */
	  //ս������
	  var scene=$(".war-scene");
	  //��
	  var trees=$(".tree");
	  //��ƺ
	  var grasses=$(".grass");
	  //bossǽ
      var bosswalls=$(".boss-wall");
      //bossǽ���˵Ĵ���
	  bosswalls.data("hits",0);
	  //boss
	  var boss=$(".boss");
	  //boss���˵Ĵ���
	  boss.data("hits",0);  
	  //�Լ���̹��
	  var mytank=$(".tank");
	      mytank.data({
		  //̹�˵��ٶ�
		  tankspeedx:6,
		  tankspeedy:6,
		  //̹�˵�ǰ�ķ���
		  tankdir:"",
		  tankAngle:0,
		  //�Ƿ񿪻�
		  fire:true
		  })
		//̹��Ͳ
		  var tankhead=$(".tankhead");
		  tankhead.data({
		  tankHeadAngle:0
		  })

	    //������̹��
		myTankRun(scene,bosswalls,boss,mytank,tankhead,trees,dtankarr);
		//���е�̹��
		dTankRun(scene,bosswalls,boss,mytank,trees,dtankarr);

		//����һ��
		$(".agianbtn").click(function  () {
             $(".agian").animate({top:-470},500);
			 location.reload();
		})
		//��һ��
        $(".nextbtn").click(function  () {
			  $(".backmask").animate({opacity:0},500);
             $(".next").animate({top:-470},500);
			 //������̹��
		myTankRun(scene,bosswalls,boss,mytank,tankhead,trees,dtankarr);
		//���е�̹��
		dTankRun(scene,bosswalls,boss,mytank,trees,dtankarr);
		})
		
    })

	function init () {
		//��̹�˹�λ
		$(".tank").css({
		left:"358px",top:"362px",display:"block"
		});
		$(".boss").css({display:"block"});
		//���ٵ�̹��
		if($(".dtank").length!==0){
		  $(".dtank").remove();
		}
	}
	function initData () {
		//���һ�µ�ǰ�Ĺؿ���
		$(window).data("guanka",!$(window).data("guanka")?1:$(window).data("guanka"));
	    //��̹�˵��ٶ�
		$(window).data("dspeed",3);
		//��̹�˵�����
		$(window).data("dnum",1);
		//��̹���ӵ����ٶ�
		$(window).data("dshellspeed",10);
		//����Ƶ��
		var level=$(window).data("level");
		if(!$(window).data("step")){
		    if(level=="ease"){
			  $(window).data("step",1);
			}else	if(level=="normal"){
				$(window).data("step",2);
			}else	if(level=="hard"){
			   $(window).data("step",3);
			}
		}
	}
})

function replay () {
	clearInterval(dtankarr.t1);
	clearInterval(dtankarr.t2);
	clearInterval(dtankarr.t3);
	clearInterval(dtankarr.t4);
	clearInterval(dtankarr.t5);
	clearInterval(dtankarr.t6);
	clearInterval(dtankarr.t7);
	$(".backmask").animate({opacity:1},1000);
	$(".agian").css({
	left:($(window).width()-635)/2,
	top:-470,
	display:"block"
	}).animate({top:($(window).height()-470)/2},500);
}

function next () {
    clearInterval(dtankarr.t1);
	clearInterval(dtankarr.t2);
	clearInterval(dtankarr.t3);
	clearInterval(dtankarr.t4);
	clearInterval(dtankarr.t5);
	clearInterval(dtankarr.t6);
	clearInterval(dtankarr.t7);
    $(".backmask").animate({opacity:1},1000);
	for (var i=0; i<dtankarr.length; i++) {
		dtankarr[i].data("shell").remove();
		dtankarr[i].remove;
		dtankarr[i]=null;
	}
	dtankarr.length=0;
	$(".mask").unbind();
	$(document).unbind();
    $(".next").css({
	left:($(window).width()-635)/2,
	top:-470,
	display:"block"
	}).animate({top:($(window).height()-470)/2},500);
	$(window).data("guanka",$(window).data("guanka")+1);
	dtankarr.next=false;
}
