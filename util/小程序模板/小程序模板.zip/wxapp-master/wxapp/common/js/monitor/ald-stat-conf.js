let conf = require('../../../app.confing').monitor
exports.app_key = conf.ald.appKey
exports.getLocation = conf.ald.getLocation
exports.plugin = conf.ald.plugin
exports.useOpen = conf.ald.useOpen

