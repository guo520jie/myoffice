// SDK版本: 1.0.5
let conf = require('../../../app.confing').monitor
exports.appid = conf.smwt.appKey
exports.trackid = conf.smwt.trackid
exports.getLocation = conf.smwt.getLocation