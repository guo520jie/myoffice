Component({
  options: {
    styleIsolation: 'isolated',
  },
  properties: {
  },
  data: {
  },
  methods: {
  }
})
