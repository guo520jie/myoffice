
// 请在此行填写从PITAYA后台获取的appkey
exports.pitayaKey = 'k0Ju6mDeg39G15dojPQSmGbdnocis0ys';
// 自动上传用户坐标位置 如果有
exports.getLocation = false;
// 自动上传用户头像昵称 如果有
exports.getUserInfo = false;