import Vue from 'vue'
import moment from 'moment'

// 注册全局过滤器
// format = 'YYYY' 语法是：ES6中默认参数的语法
Vue.filter('date', function (value, format = 'YYYY-MM-DD HH:mm:ss') {
  // value 表示要格式化的数据
  // format 表示传递给过滤器的参数
  return moment(value).format(format)
})