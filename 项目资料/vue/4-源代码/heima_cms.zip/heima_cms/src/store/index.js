import Vue from 'vue'
import Vuex from 'vuex'
Vue.use(Vuex)

const cart = JSON.parse(localStorage.getItem('cart')) || []

const store = new Vuex.Store({
  state: {
    cart
    // cart: []
    // cart: [
    //   { id: 87, count: 1 },
    //   { id: 88, count: 2}
    // ]
  },

  // 同步修改状态
  mutations: {
    // 添加商品到购物车中
    addGoodsToCart(state, payload) {
      // payload: {id: 87, count: 1}
      // 思路：
      //  判断商品是否存在于购物车中
      //  1 如果没有，直接push到cart中
      //  2 如果有，找到id对应数量，加上传递过来的数量，重新更新这个数量
      const curGoods = state.cart.find(item => item.id === payload.id)
      if (!curGoods) {
        // 不存在
        state.cart.push({
          id: payload.id,
          count: payload.count
        })
      } else {
        curGoods.count += payload.count
      }

      localStorage.setItem('cart', JSON.stringify(state.cart))
    },

    // 更新购物车数据的方法
    updateCart(state, payload) {
      // payload 就是 最新的购物车list
      state.cart = payload.map(item => {
        if (item.isChecked) {
          return { id: item.id, count: item.count }
        } else {
          // 没有勾选该商品
          return { id: item.id, count: 0 }
        }
      })

      localStorage.setItem('cart', JSON.stringify(state.cart))
    }
  },

  // getters 相当于 Vuex 的计算属性
  // 读取getters： $store.getters.getCartCount
  getters: {
    // 获取商品总数量
    getCartCount(state) {
      let count = 0
      state.cart.forEach(item => count += item.count)
      return count
    },

    // 获取ids：87,88,89 字符串
    getIds(state) {
      return state.cart.map(item => item.id).join(',')
    },

    // 根据id获取到商品数量
    // const obj = {88: 2, 87: 3}
    // obj[88]
    getCountById(state) {
      const idsObj = {}
      state.cart.forEach(item => {
        idsObj[item.id] = item.count
      })
      return idsObj
    }
  },

  // 异步修改状态
  actions: {
    // 异步添加商品
    addGoodsToCartAsync(context, payload) {
      setTimeout(() => {
        // 通过调用 mutations 来异步 添加商品
        context.commit('addGoodsToCart', { id: payload.id, count: payload.count })
      }, 600);
    }
  }
})

export default store