<template>
  <div class="container">
    <!-- 顶部标题 -->
    <mt-header fixed title="黑马程序员 | SH17">
      <a href="#" @click.prevent="$router.go(-1)" slot="left" v-show="$route.path !== '/home'">
        <mt-button icon="back">返回</mt-button>
      </a>
    </mt-header>

    <!-- 内容: 路由出口 -->
    <router-view class="content"></router-view>

    <!-- 底部导航菜单 -->
    <nav class="mui-bar mui-bar-tab">
			<!-- 因为要给 router-link 组件绑定一个原生事件，所以，需要添加 .native 事件修饰符才可以 -->
			<router-link class="mui-tab-item" to="/home" @click.native="goPage('/home')">
				<span class="mui-icon mui-icon-home"></span>
				<span class="mui-tab-label">首页</span>
			</router-link>
			<router-link class="mui-tab-item" to="/vip" @click.native="goPage('/vip')">
				<span class="mui-icon mui-icon-contact"></span>
				<span class="mui-tab-label">会员</span>
			</router-link>
			<router-link class="mui-tab-item" to="/cart" @click.native="goPage('/cart')">
				<span class="mui-icon mui-icon-extra mui-icon-extra-cart"><span class="mui-badge">{{ $store.getters.getCartCount }}</span></span>
				<span class="mui-tab-label">购物车</span>
			</router-link>
			<router-link class="mui-tab-item" to="/search" @click.native="goPage('/search')">
				<span class="mui-icon mui-icon-search"></span>
				<span class="mui-tab-label">搜索</span>
			</router-link>
		</nav>
  </div>
</template>

<script>
export default {
	methods: {
		// 通过编程式导航实现页面跳转，解决 mui 代码对底部导航菜单的影响（bug）
		goPage(page) {
			// console.log('页面跳转了');
			this.$router.push(page)
		}
	}
}
</script>

<style scoped>
  /* 说明： 顶部固定导航栏 header 是固定定位的，“吃掉”了内容的一部分高度，所以，我们通过给内容区域添加 padding 来空出吃掉的部分 */
  .content {
    padding: 40px 0 50px 0;
  }
</style>
