<template>
  <div>
    <div class="news-info">
      <header>
        <h3 v-text="info.title"></h3>
        <p class="news-desc">
          <span>发表时间：{{ info.add_time | date }}</span>
          <span>点击次数：{{ info.click }}次</span>
        </p>
      </header>

      <!-- 新闻内容 -->
      <div class="news-content" v-html="info.content"></div>

      <!-- 评论组件 -->
      <!-- 将当前组件中的id参数，通过组件通讯的方式传递给Comment组件 -->
      <Comment :commentId="$route.params.id"></Comment>
    </div>
  </div>
</template>

<script>
// 导入评论组件
import Comment from '../common/Comment.vue'

export default {
  // 钩子函数
  created() {
    this.getNewsInfoById()
  },

  // 数据
  data() {
    return {
      info: {}, // 新闻详情
    }
  },

  // 方法
  methods: {
    // 获取新闻详情
    getNewsInfoById() {
      this
        .$http
        // 字符串模板的语法：${} 用来代替原始的字符串拼接
        .get(`http://vue.studyit.io/api/getnew/${this.$route.params.id}`)
        .then(res => {
          const data = res.data

          if (data.status === 0) {
            this.info = data.message[0]
          }
        })
    }
  },

  // 注册组件
  components: { Comment }
}
</script>

<style lang="scss">
  .news-info {
    padding: 5px;

    header, .news-content {
      border-bottom: 1px solid #ccc;
    }

    h3 {
      font-size: 18px;
    }

    .news-desc {
      display: flex;
      justify-content: space-between;
      color: #26a2ff;
    }

    img {
      width: 100%;
    }
  }
</style>
