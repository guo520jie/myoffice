<template>
  <div class="photo-info">
    <header>
      <h2 class="title">{{ info.title }}</h2>
      <p class="mui-ellipsis">
        <span>发表时间：{{ info.add_time | date }}</span>
        <span>点击次数：{{ info.click }}次</span>
      </p>
    </header>
    <div class="thumb-img">
      <img :src="item.src" height="100" class="preview-img" v-for="(item, index) in list" :key="index" @click="$preview.open(index, list)">
    </div>
    <div class="content" v-html="info.content">
    </div>

    <!-- 评论组件 -->
    <Comment :commentId="$route.params.id"></Comment>
  </div>
</template>

<script>
// 因为这个插件只在当前组件中使用了，所以，直接放到这个组件中引入即可
import Vue from 'vue'
import VuePreview from 'vue-preview'
Vue.use(VuePreview)

// 导入评论组件
import Comment from '../common/Comment.vue'

export default {
  created() {
    this.getImageInfoById()
    this.getThumImagesById()
  },

  data() {
    return {
      info: {}, // 图片详情
      list: []  // 缩略图数组
    }
  },

  methods: {
    // 根据id获取图片详情信息
    getImageInfoById() {
      this.$http
        .get(`http://vue.studyit.io/api/getimageInfo/${this.$route.params.id}`)
        .then(res => {
          const data = res.data

          if (data.status === 0) {
            this.info = data.message[0]
          }
        })
    },

    // 根据id获取缩略图列表
    getThumImagesById() {
      this.$http
        .get(`http://vue.studyit.io/api/getthumimages/${this.$route.params.id}`)
        .then(res => {
          const data = res.data 

          if (data.status === 0) {
            // 因为 vue-preview 插件中要求每个数据都包含 w 和 h 属性，而我们获取的数据中没有这两个属性，所以，需要添加这个两个属性才可以
            // map()方法会根据当前数组生成一个新的数组，新数组中的每一项值是由map方法的回调函数的返回值决定的！！！
            this.list = data.message.map(item => ({
                src: item.src,
                w: 600,
                h: 400
              })
            )

            // this.list = data.message.map(function (item) {
            //   return {
            //     src: item.src,
            //     w: 600,
            //     h: 400
            //   }
            // })
          }
        })
    }
  },

  // 注册为局部组件，才可以在当前组件中使用
  components: {Comment}
}
</script>

<style lang="scss">
.photo-info {
  padding-left: 3px;
  padding-right: 3px;

  .thumb-img {
    border-top: 1px solid #ccc;

    img {
      margin: 9px;
      box-shadow: 0 0 15px #ccc;
    }
  }

  .title {
    font-size: 18px;
    color: #26a2ff;
    text-align: center;
  }

  .mui-ellipsis {
    display: flex;
    justify-content: space-between;
    padding: 0 3px;
  }

  .content {
    font-size: 14px;
    line-height: 28px;
    padding-top: 20px;
  }
}
</style>
