<template>
  <div>
    <h1>搜索您需要的内容</h1>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
