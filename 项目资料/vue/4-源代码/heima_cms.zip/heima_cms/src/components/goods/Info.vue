<template>
  <div class="goods-info">
    <!-- 轮播图 -->
    <div class="mui-card">
      <div class="mui-card-content">
        <div class="mui-card-content-inner">
          <!-- 轮播图组件 -->
          <mt-swipe :auto="4000">
            <mt-swipe-item v-for="(item, index) in goodsImgsList" :key="index">
              <img :src="item.src" alt="商品图片">
            </mt-swipe-item>
          </mt-swipe>
        </div>
      </div>
    </div>

    <!-- 飞舞的小球 -->
    <transition 
      @before-enter="beforeEnter"
      @enter="enter">
      <!-- 要执行动画效果的div元素 -->
      <div class="ball" v-show="isShow"></div>
    </transition>

    <!-- 商品数据展示 -->
    <div class="mui-card">
      <div class="mui-card-header">{{ info.title }}</div>
      <div class="mui-card-content">
        <div class="mui-card-content-inner info">
          <p>
            <span class="market-price">市场价：<del>￥{{ info.market_price }}</del></span> 
            <span>
            销售价：
            <span class="sell-price">￥{{ info.sell_price }}</span>
            </span>
          </p>
          <div class="numbox-container">
            购买数量：
            <!-- max 表示能够选择的最大数量 -->
            <NumberBox v-model="count" :max="info.stock_quantity"></NumberBox>
          </div>
          <div>
            <mt-button type="primary">立即购买</mt-button>
            <mt-button type="danger" @click="addCart">加入购物车</mt-button>
          </div>
        </div>
      </div>
    </div>
    
    <!-- 商品参数 -->
    <div class="mui-card">
      <div class="mui-card-header">商品参数</div>
      <div class="mui-card-content">
        <div class="mui-card-content-inner">
          <p>商品货号：{{ info.goods_no }}</p>
          <p>库存情况：{{ info.stock_quantity }}件</p>
          <p>上架时间：{{ info.add_time | date('YYYY-MM-DD') }}</p>
        </div>
      </div>
      <div class="mui-card-footer">
        <mt-button type="primary" size="large" plain @click="goDetail">图文介绍</mt-button>
        <mt-button type="danger" size="large" plain @click="goComment">商品评论</mt-button>
      </div>
    </div>
  </div>
</template>

<script>
// 导入 NumberBox 组件
import NumberBox from '../common/NumberBox.vue'

export default {
  created() {
    this.getGoodsInfoById()
    this.getGoodsImgs()
  },

  data() {
    return {
      info: {}, // 商品信息数据
      goodsImgsList: [], // 商品的图片数组
      count: 1, // 商品购买数量
      isShow: false // 控制小球的展示和隐藏，false表示隐藏
    }
  },

  methods: {
    // 根据商品id获取商品信息
    getGoodsInfoById() {
      this.$http
        .get(`http://vue.studyit.io/api/goods/getinfo/${this.$route.params.id}`)
        .then(res => {
          const data = res.data

          if (data.status === 0) {
            this.info = data.message[0]
          }
        })
    },

    // 获取商品图片数组
    getGoodsImgs() {
      this.$http
        .get(`http://vue.studyit.io/api/getthumimages/${this.$route.params.id}`)
        .then(res => {
          const data = res.data

          if (data.status === 0) {
            this.goodsImgsList = data.message
          }
        })
    },

    // 查看商品图文介绍
    goDetail() {
      this.$router.push(`/home/goodsdetail/${this.$route.params.id}`)
    },

    // 查看商品评论信息
    goComment() {
      this.$router.push(`/home/goodscomment/${this.$route.params.id}`)
    },

    // 添加商品到购物车
    addCart() {
      // 展示小球
      this.isShow = true

      this.$store.dispatch('addGoodsToCartAsync', { id: this.$route.params.id - 0, count: this.count })

      // setTimeout(() => {
      //   this.$store.commit('addGoodsToCart', { id: this.$route.params.id - 0, count: this.count })
      // }, 600);
    },

    // 动画效果方法
    beforeEnter(el) {
      // el表示执行动画效果的DOM对象
      console.log('beforeEnter');

      // 动画的初始位置
      el.style.transform = 'translate(0, 0)'
    },
    enter(el, done) {
      // done 表示成功标识，也就是说：动画执行完成了，只有调用了done方法后，afterEnter钩子函数才会执行
      console.log('enter');

      // 通过这句话触发浏览器的重绘和重排机制，这样，前后两次设置的动画效果就会生效了
      // el.offsetWidth
      
      // 动画的结束位置
      el.style.transform = `translate(90px, ${window.pageYOffset + 236}px)`
      this.isShow = false
      // done()
    },
    // afterEnter(el) {
    //   console.log('afterEnter');
    // }
  },

  // 注册组件
  components: {NumberBox}
}
</script>

<style lang="scss">
  .mint-swipe {
    height: 200px;

    .mint-swipe-item {
      text-align: center;

      img {
        height: 100%;
        // width: 100%;
      }
    }
  }

  .info {

    p {
      color: #000;

      .market-price {
        margin-right: 10px;
      }

      .sell-price {
        color: #f00;
        font-size: 16px;
        font-weight: bold;
      }
    }

    .mui-numbox {
      height: 25px;
    }

    .numbox-container {
      margin-bottom: 10px;
    }

    .mint-button {
      font-size: 14px;
      height: 34px;
    }
  }

  .mui-card-footer {
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    height: 120px;
  }

  .ball {
    width: 16px;
    height: 16px;
    border-radius: 50%;
    background-color: #f00;
    position: absolute;
    z-index: 11;
    top: 385px;
    left: 151px;
    /* 通过 贝塞尔曲线 设置动画效果 */
    transition: all 0.6s ease;
    // transition: all 0.6s cubic-bezier(.3,1.83,.67,-2.28)
  }
</style>
