import Vue from 'vue'
// 导入路由
import VueRouter from 'vue-router'
Vue.use(VueRouter)

// 导入 自定义功能组件
import Home from '../components/home/Home.vue'

// 将以下所有的导入组件的方式修改为 支持按需加载 的语法形式
// 'vip'参数：表示将来生成的js文件的名称
// const Vip = r => require.ensure([], () => r(require('../components/vip/Vip.vue')), 'vip')

// 推荐使用这个语法！！！！
// 注意：/* webpackChunkName: "vip" */是特殊的语法，用来指定生成js文件的名称
const Vip = () => import(/* webpackChunkName: "vip" */ '../components/vip/Vip.vue')
const Cart = () => import(/* webpackChunkName: "cart" */ '../components/cart/Cart.vue')
const Search = () => import(/* webpackChunkName: "search" */ '../components/search/Search.vue')

// 新闻
// 注意：如果 chunckname 相同，那么多个vue组件就会被打包成一个js文件
const NewsList = () => import(/* webpackChunkName: "news" */ '../components/news/List.vue')
const NewsInfo = () => import(/* webpackChunkName: "news" */ '../components/news/Info.vue')

// 图片分析
const PhotoList = () => import(/* webpackChunkName: "photo" */ '../components/photos/List.vue')
const PhotoInfo = () => import(/* webpackChunkName: "photo" */ '../components/photos/Info.vue')

// 商品
const GoodsList = () => import(/* webpackChunkName: "goods" */ '../components/goods/List.vue')
const GoodsInfo = () => import(/* webpackChunkName: "goods" */ '../components/goods/Info.vue')
const GoodsDetail = () => import(/* webpackChunkName: "goods" */ '../components/goods/Detail.vue')
const GoodsComment = () => import(/* webpackChunkName: "goods" */ '../components/goods/Comment.vue')

// import Vip from '../components/vip/Vip.vue'
// import Cart from '../components/cart/Cart.vue'
// import Search from '../components/search/Search.vue'
// 导入新闻组件
// import NewsList from '../components/news/List.vue'
// import NewsInfo from '../components/news/Info.vue'
// 导入图片分享组件
// import PhotoList from '../components/photos/List.vue'
// import PhotoInfo from '../components/photos/Info.vue'
// 导入商品购买组件
// import GoodsList from '../components/goods/List.vue'
// import GoodsInfo from '../components/goods/Info.vue'
// import GoodsDetail from '../components/goods/Detail.vue'
// import GoodsComment from '../components/goods/Comment.vue'

// 配置路由规则
const router = new VueRouter({
  routes: [
    { path: '/', redirect: '/home' },
    { path: '/home', component: Home },
    { path: '/vip', component: Vip },
    { path: '/cart', component: Cart },
    { path: '/search', component: Search },

    // 注意 path 中，添加了 /home 的目的是为了让底部的首页菜单保持高亮
    { path: '/home/newslist', component: NewsList },
    // :id  动态路径参数（路由参数）
    { path: '/home/newsinfo/:id', component: NewsInfo },

    { path: '/home/photolist', component: PhotoList },
    { path: '/home/photoinfo/:id', component: PhotoInfo, name: 'photoinfo' },

    { path: '/home/goodsList', component: GoodsList },
    { path: '/home/goodsinfo/:id', component: GoodsInfo },
    { path: '/home/goodsdetail/:id', component: GoodsDetail },
    { path: '/home/goodscomment/:id', component: GoodsComment },
  ],

  // 修改 路由默认的激活类名
  linkActiveClass: 'mui-active'
})

// 导出路由
export default router