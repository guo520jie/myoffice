// 1 导入 vue
import Vue from 'vue'

// 2 导入App.vue组件
import App from './App.vue'

// 导入 mui 的样式
import './lib/mui/css/mui.min.css'
// 导入 mui extra 的样式
import './lib/mui/css/icons-extra.css'
// 导入自定义样式 -- 注意：样式覆盖的问题，先引入 mui 的样式，再引入我们自己写的样式
import './assets/css/index.css'

// 导入路由
import router from './router'

// 导入 mint-ui 组件
import { Header, Button, Swipe, SwipeItem, Lazyload, Switch, Indicator } from 'mint-ui'

// 注册组件
Vue.component(Header.name, Header)
Vue.component(Button.name, Button)
Vue.component(Swipe.name, Swipe)
Vue.component(SwipeItem.name, SwipeItem)
Vue.component(Switch.name, Switch)
// 注意：LazyLoad 是一个Vue插件
Vue.use(Lazyload)

// 导入 axios
// 注意：axios 不是vue的插件，与vue没有任何关系
import axios from 'axios'
// 配置axios的基础路径
axios.defaults.baseURL = 'http://vue.studyit.io'

// 使用axios的请求拦截器，给所有的请求添加loading效果
axios.interceptors.request.use(function (config) {
  // console.log('拦截器', config);

  Indicator.open({
    text: '加载中...',
    spinnerType: 'fading-circle'
  });
  
  return config;
}, function (error) {
  // 请求报错
  return Promise.reject(error);
});

// 响应拦截器
axios.interceptors.response.use(function (response) {
  setTimeout(() => {
    Indicator.close();
  }, 500);

  return response;
});

// 将 axios 添加到 Vue的原型中
Vue.prototype.$http = axios

// 导入 过滤器
import './filter'

// 导入 vuex
import store from './store'

// 3 创建Vue实例
new Vue({
  el: '#app',
  router,
  store,
  render: c => c(App)
})