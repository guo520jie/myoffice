const path = require('path')
const webpack = require('webpack')
const htmlWebpackPlugin = require('html-webpack-plugin')
const cleanWebpackPlugin = require('clean-webpack-plugin')
// 分离 css 到独立的文件中
const ExtractTextPlugin = require("extract-text-webpack-plugin");
// 压缩 css 资源文件
const OptimizeCssAssetsPlugin = require('optimize-css-assets-webpack-plugin')

module.exports = {
  entry: {
    // 我们自己写的代码的入口
    // 注意：app 可以是任意的名称
    app: path.join(__dirname, './src/main.js'),
    // vendor 表示第三方的包
    vendor: ['vue', 'vue-router', 'mint-ui', 'moment', 'vue-preview', 'vuex', 'axios']
  },

  output: {
    path: path.join(__dirname, './dist'),

    // 设置公共路径，全部采用绝对路径的形式，来解决：字体文件路径的bug
    publicPath: '/',

    // 修改出口，将所有的js文件放到 js 目录中
    filename: 'js/[name].[chunkhash].js',

    // ------添加 chunkFilename, 指定代码分离后的js文件名称------
    chunkFilename: 'js/[name].[chunkhash].js',
  },

  module: {
    rules: [{
        test: /\.css$/,
        use: ExtractTextPlugin.extract({
          fallback: "style-loader",
          use: "css-loader"
        })
      },
      {
        test: /\.(sass|scss)$/,
        use: ExtractTextPlugin.extract({
          fallback: "style-loader",
          use: ['css-loader', 'sass-loader']
        })
      },
      {
        test: /\.(png|jpg|jpeg|gif)$/,
        use: {
          loader: 'url-loader',
          options: {
            limit: 8192,
            // 用来指定生成文件的路径以及命名规则
            // images 表示将图片放到哪个文件键中
            // [hash:7] 表示使用hash算法，将图片名称重命名为 7位的名称
            // [ext] 表示保持原始图片后缀名称
            name: 'images/[hash:7].[ext]'
          }
        }
      },
      {
        test: /\.(eot|woff|woff2|ttf|svg|otf)$/,
        use: {
          loader: 'file-loader',
          options: {
            // 用来指定生成文件的路径以及命名规则
            name: 'fonts/[hash:10].[ext]'
          }
        }
      },

      // mui 的路径中包含：lib
      // 将 mui 排除，不经过 babel 的处理，那么，mui的代码就不会运行在 严格模式 中了！
      // 只要经过 babel 处理的js文件，都会默认升级为：严格模式
      {
        test: /\.js$/,
        use: 'babel-loader',
        exclude: /node_modules|lib/
      },
      // 解决 vue-preview 插件中使用ES6代码，无法被 uglifyjs 压缩的bug
      {
        test: /vue-preview.src.*?js$/,
        use: 'babel-loader'
      },
      {
        test: /\.vue$/,
        use: 'vue-loader'
      }
    ]
  },

  plugins: [
    new htmlWebpackPlugin({
      template: path.join(__dirname, './src/index.html'),

      // 压缩HTML
      minify: {
        // 移除空白
        collapseWhitespace: true,
        // 移除注释
        removeComments: true,
        // 移除属性中的双引号
        removeAttributeQuotes: true
      }
    }),

    // 自动删除dist目录
    new cleanWebpackPlugin(['./dist']),

    // 抽离第三方包
    new webpack.optimize.CommonsChunkPlugin({
      // 第三方包入口名称，对应 entry 中的 vendor 属性
      name: 'vendor',
    }),

    // 压缩js
    new webpack.optimize.UglifyJsPlugin({
      compress: {
        // 移除警告
        warnings: false
      }
    }),

    // 指定环境为生产环境：vue会根据这一项启用压缩后的vue文件
    new webpack.DefinePlugin({
      'process.env': {
        'NODE_ENV': JSON.stringify('production')
      }
    }),

    // 通过插件抽离 css (参数)
    new ExtractTextPlugin('css/style.css'),
    // 抽离css 的辅助压缩插件
    new OptimizeCssAssetsPlugin(),
  ]
}