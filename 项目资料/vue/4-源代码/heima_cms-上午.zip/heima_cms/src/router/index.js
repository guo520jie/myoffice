import Vue from 'vue'
// 导入路由
import VueRouter from 'vue-router'
Vue.use(VueRouter)

// 导入 自定义功能组件
import Home from '../components/home/Home.vue'
import Vip from '../components/vip/Vip.vue'
import Cart from '../components/cart/Cart.vue'
import Search from '../components/search/Search.vue'
// 导入新闻组件
import NewsList from '../components/news/List.vue'
import NewsInfo from '../components/news/Info.vue'
// 导入图片分享组件
import PhotoList from '../components/photos/List.vue'
import PhotoInfo from '../components/photos/Info.vue'
// 导入商品购买组件
import GoodsList from '../components/goods/List.vue'
import GoodsInfo from '../components/goods/Info.vue'
import GoodsDetail from '../components/goods/Detail.vue'
import GoodsComment from '../components/goods/Comment.vue'

// 配置路由规则
const router = new VueRouter({
  routes: [
    { path: '/', redirect: '/home' },
    { path: '/home', component: Home },
    { path: '/vip', component: Vip },
    { path: '/cart', component: Cart },
    { path: '/search', component: Search },

    // 注意 path 中，添加了 /home 的目的是为了让底部的首页菜单保持高亮
    { path: '/home/newslist', component: NewsList },
    // :id  动态路径参数（路由参数）
    { path: '/home/newsinfo/:id', component: NewsInfo },

    { path: '/home/photolist', component: PhotoList },
    { path: '/home/photoinfo/:id', component: PhotoInfo, name: 'photoinfo' },

    { path: '/home/goodsList', component: GoodsList },
    { path: '/home/goodsinfo/:id', component: GoodsInfo },
    { path: '/home/goodsdetail/:id', component: GoodsDetail },
    { path: '/home/goodscomment/:id', component: GoodsComment },
  ],

  // 修改 路由默认的激活类名
  linkActiveClass: 'mui-active'
})

// 导出路由
export default router