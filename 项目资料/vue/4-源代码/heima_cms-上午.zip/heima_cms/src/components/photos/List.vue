<template>
  <div>
    <div class="mui-slider mui-fullscreen">
			<div class="mui-scroll-wrapper mui-slider-indicator mui-segmented-control mui-segmented-control-inverted">
				<div class="mui-scroll">
          <!-- mui-active 这个类，应该只在当前菜单中存在 -->
          <!-- 只有当 item.id === 0 的时候，才会给当前元素添加这个类 -->
          <a href="#" class="mui-control-item" :class="{ 'mui-active': item.id === 0 }" v-for="item in categoryList" :key="item.id" @click="getImagesById(item.id)">
						{{ item.title }}
					</a>
        </div>
			</div>
		</div>

		<!-- 图片列表 -->
		<ul class="category-img-list">
      <li class="img-list-item" v-for="item in imagesList" :key="item.id" @click="goInfo(item.id)">
        <img v-lazy="item.img_url"> 
        <div>
          <h2>{{ item.title }}</h2>
          <p>{{ item.zhaiyao }}</p>
        </div>
      </li>
    </ul>
  </div>
</template>

<script>
// 导入 mui
// 因为我们使用的环境是ES6，而ES6中默认开启严格模式，而mui中的代码没有遵循严格模式，那么，使用mui的代码后，就会报错了！
import mui from '../../lib/mui/js/mui.min'

export default {
  mounted() {
    // 因为mui要进行DOM操作，所以，需要在mounted钩子函数中调用才可以！！！
    mui('.mui-scroll-wrapper').scroll({
      deceleration: 0.0005 // 减速系数
    })

    // 获取顶部横向导航菜单
    this.getImgCategory()

    // 进入页面获取全部图片分类数据
    this.getImagesById(0)
  },

  data() {
    return {
      categoryList: [], // 顶部横向导航菜单
      imagesList: []    // 图片分类列表数据
    }
  },

  methods: {
    // 获取顶部横向导航 图片分类数据
    getImgCategory() {
      this.$http
        .get('http://vue.studyit.io/api/getimgcategory')
        .then(res => {
          const data = res.data

          if (data.status === 0) {
            this.categoryList = [{id: 0, title: '全部'}, ...data.message]
          }
        })
    },

    // 根据 id 获取分类图片列表数据
    getImagesById(id) {
      this.$http
        .get(`http://vue.studyit.io/api/getimages/${id}`)
        .then(res => {
          const data = res.data

          if (data.status === 0) {
            this.imagesList = data.message
          }
        })
    },

    // 根据id跳转到详情中
    goInfo(id) {
      // 根据路由的name属性，来指定跳转到哪个路由中
      this.$router.push({ name: 'photoinfo', params: { id } })
    }
  }
}
</script>

<style lang="scss">
.mui-slider-indicator.mui-segmented-control {
  background-color: #fff;
}

.mui-fullscreen {
  position: fixed;
  top: 40px;
  height: 38px;
}

/* scroll滚动警告的处理方式参考：http://www.jianshu.com/p/baf61adc8667 */
* {
  touch-action: none;
}

.category-img-list {
  list-style: none;
  padding: 5px;
  padding-top: 30px;

  img[lazy=loading] {
    width: 40px;
    height: 300px;
    margin: auto;
  }

  .img-list-item {
    position: relative;
    margin-bottom: 5px;

    div {
      position: absolute;
      bottom: 0;
      background-color: rgba(0, 0, 0, 0.2);
      color: #fff;

      h2 {
        font-size: 16px;
      }

      p {
        color: #fff;
        margin-bottom: 0px;
      }
    }

    img {
      display: block;
      width: 100%;
    }
  }
}
</style>
