<template>
  <div>
    <div class="mui-card">
      <div class="mui-card-content">
        <div class="mui-card-content-inner cart" v-for="item in list" :key="item.id">
          <!-- 开关组件 -->
          <mt-switch v-model="item.isChecked"></mt-switch>
          <img :src="item.thumb_path" alt="购物车商品缩略图">
          <div>
            <h2>{{ item.title }}</h2>
            <div class="info">
              <span>￥{{ item.sell_price }}</span> 
              <NumberBox v-model="item.count"></NumberBox>
              <!-- 通过事件修饰符 prevent 阻止a标签修改href中哈希值的默认行为 -->
              <a href="#" @click.prevent="delGoods(item.id)">删除</a>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="mui-card">
      <div class="mui-card-content">
        <div class="mui-card-content-inner cart-buy">
          <div>
            <p>总计（不包含运费）</p>
            <p>已勾选商品&nbsp;
              <span>{{ $store.getters.getCartCount }}</span>&nbsp;件&nbsp;&nbsp;总价：
              <span>￥{{ totalPrice }}</span></p>
          </div>
          <div>
            <mt-button type="danger">去结算</mt-button>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import NumberBox from '../common/NumberBox.vue'

export default {
  created() {
    this.getShopCarListByIds()
  },

  data() {
    return {
      list: []  // 购物车商品数组
    }
  },

  // 分析发现，每个商品中都有4个点，能够影响数据的改变
  // 所以，简单的处理方式就是：直接监视 list 这个数组的改变，当list发生改变，就更新购物车中的数据。因为购物车数量和商品价格，都是计算属性，所以，只要购物车中的数据改变了，那么计算属性就会被重新计算，然后，更新页面结构
  watch: {
    // 监视对象属性的变化
    list: {
      handler(curVal) {
        // curVal 就是最新的 list
        this.$store.commit('updateCart', curVal)
        // 监视到变化后要执行的函数
        // console.log('list中的数据改变了');
      },
      deep: true
    }
  },

  // 计算属性：用来实现总价格
  computed: {
    // 总价格
    totalPrice() {
      let total = 0
      this.list.forEach(item => {
        // 只有当前商品选中了，才记录总价
        if (item.isChecked) {
          total += item.count * item.sell_price
        }
      })
      return total
    },
  },

  methods: {
    // 根据 ids （商品id字符串）获取购物车商品列表信息
    getShopCarListByIds() {
      // 将 ids，getCountById 从 getters 对象中解构出来
      const { getIds, getCountById } = this.$store.getters

      this.$http
        .get(`http://vue.studyit.io/api/goods/getshopcarlist/${getIds}`)
        .then(res => {
          const data = res.data

          if (data.status === 0) {
            this.list = data.message.map(item => {
              return {
                ...item,
                // 控制商品选中状态的数据
                isChecked: true,
                // 添加到购物车中的商品数量
                count: getCountById[item.id]
              }
            })
          }
        })
    },

    // 根据id删除商品
    delGoods(id) {
      for (var i = 0; i < this.list.length; i++) {
        if (this.list[i].id === id) {
          this.list.splice(i, 1)
          break
        }
      }
    }
  },

  components: {NumberBox}
}

/* const obj = {
  name: 'ja ck',
  age: 19
}

// 相当于：const name = obj.name ; const age = obj.age
const { name, age } = obj */
</script>

<style lang="scss" scoped>
.cart {
  display: flex;
  align-items: center;
  justify-content: space-between;

  h2 {
    font-size: 14px;
  }

  img {
    height: 60px;
  }

  span {
    color: #f00;
  }

  .info {
    display: flex;
    justify-content: space-between;
    align-items: center;

    h2 {
      overflow: hidden;
      text-overflow: ellipsis;
      display: -webkit-box;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
    }
  }
}

.cart-buy {
  display: flex;
  justify-content: space-between;
  align-items: center;

  span {
    color: #f00;
  }
}
</style>
