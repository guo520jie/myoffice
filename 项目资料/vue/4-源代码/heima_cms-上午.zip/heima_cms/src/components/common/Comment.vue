<template>
  <!-- 评论功能 -->
  <div class="comment">
    <h3>发表评论</h3>
    <div>
      <textarea cols="30" rows="5" placeholder="请输入评论内容，最多输入120字" v-model="comment"></textarea>
    </div>
    <mt-button type="primary" size="large" @click="addComment">发表评论</mt-button>
    <ul class="comment-list">
      <li class="comment-item" v-for="(item, index) in list" :key="index">
        <h4 class="comment-header">
          <span>第{{index + 1}}楼</span>
          <span>用户: {{ item.user_name }}</span>
          <span>发表时间：{{ item.add_time | date }}</span>
        </h4>
        <p class="comment-content">{{ item.content }}</p>
      </li>
    </ul>
    <mt-button type="primary" size="large" plain @click="getMoreComment">加载更多</mt-button>
  </div>
</template>

<script>
export default {
  // 钩子函数
  created() {
    this.getCommentsById()
  },

  // 通过 porps 来接收父组件中传递过来的id属性
  props: ['commentId'],

  // 数据
  data() {
    return {
      list: [],  // 评论列表数据
      pageindex: 1,  // 第几页
      comment: '' // 用户输入的评论内容
    }
  },

  // 方法
  methods: {
    // 获取评论数据
    getCommentsById() {
      this
        .$http
        .get(`http://vue.studyit.io/api/getcomments/${this.commentId}?pageindex=${this.pageindex}`)
        .then(res => {
          const data = res.data

          if (data.status === 0) {
            // this.list = this.list.concat(data.message)

            // ...this.list 是ES6中的数组展开
            this.list = [...this.list, ...data.message]
          }
        })
    },

    // 加载更多数据
    getMoreComment() {
      this.pageindex++

      this.getCommentsById()
    },

    // 发表评论
    addComment() {
      if (this.comment.trim() === '') {
        return
      }

      this.$http
        .post(`http://vue.studyit.io/api/postcomment/${this.commentId}`, `content=${this.comment}`)
        .then(res => {
          if (res.data.status === 0) {
            // 发表评论后，立即看到最新评论的内容
            this.list.unshift({
              add_time: new Date(),
              content: this.comment,
              user_name: '匿名用户'
            })

            // 清空输入的评论内容
            this.comment = ''
          }
        })
    }
  }
}
</script>

<style lang="scss">
  .comment {
    padding: 10px 5px;

    h3 {
      font-size: 26px;
    }

    .comment-list {
      list-style: none;
      margin: 0;
      padding: 0;
    }

    .comment-header {
      display: flex;
      justify-content: space-between;
      font-size: 14px;
      font-weight: normal;
      background-color: #eee;
      line-height: 26px;
    }
    
    .comment-content {
      color: #000;
      padding-left: 10px;
    }
  }
</style>
