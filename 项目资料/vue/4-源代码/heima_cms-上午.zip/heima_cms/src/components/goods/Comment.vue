<template>
  <div class="goods-comment">
    <Comment :commentId="$route.params.id"></Comment>
  </div>
</template>

<script>
import Comment from '../common/Comment.vue'

export default {
  components: {Comment}
}
</script>

<style>
  .goods-comment {
    padding: 5px;
  }
</style>
