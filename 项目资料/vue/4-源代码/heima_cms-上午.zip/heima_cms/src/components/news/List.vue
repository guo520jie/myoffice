<template>
  <div class="news-list">
    <ul class="mui-table-view mui-table-view-chevron">
      <li class="mui-table-view-cell mui-media" v-for="item in list" :key="item.id">
        <!-- 因为路由path是由两部分内容组成的：1 固定的 /home/newsinfo 2 属性item.id，所以，需要将两部分内容拼接后得到完整的path -->
        <router-link :to=" '/home/newsinfo/' + item.id " class="mui-navigate-right">
          <img class="mui-media-object mui-pull-left" :src="item.img_url">
          <div class="mui-media-body">
            <h3 class="news-title mui-ellipsis">{{ item.title }}</h3>
            <p class="news-desc">
              <span>发表时间：{{ item.add_time | date }}</span>
              <span>点击次数：{{ item.click }}次</span>
            </p>
          </div>
        </router-link>
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  // 钩子函数
  created() {
    // 获取新闻列表数据
    this.getNewsList()
  },

  // 数据
  data() {
    return {
      list: []
    }
  },

  // 方法
  methods: {
    getNewsList() {
      this
        .$http
        .get('http://vue.studyit.io/api/getnewslist')
        .then(res => {
          const data = res.data

          if (data.status === 0) {
            // 表示获取数据成功
            this.list = data.message
          }
        })
    }
  }
}
</script>

<style lang="scss" scoped>
  .news-list {
    .mui-table-view-cell {
      padding-bottom: 8px;
    }

    .news-title {
      font-weight: normal;
      font-size: 16px;
    }
    
    .news-desc {
      display: flex;
      justify-content: space-between;
      font-size: 12px;
      color: #26a2ff;
    }

    .mui-table-view-cell {
      padding-right: 52px;
    }
  }
</style>
