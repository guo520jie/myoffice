<template>
  <div>
    <h1>您好，尊敬的钻石会员 - Vip</h1>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
