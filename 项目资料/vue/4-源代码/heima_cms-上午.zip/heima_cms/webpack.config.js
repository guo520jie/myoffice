const path = require('path')
const htmlWebpackPlugin = require('html-webpack-plugin')

module.exports = {
  entry: path.join(__dirname, './src/main.js'),

  output: {
    path: path.join(__dirname, './dist'),
    filename: 'bundle.js'
  },

  devServer: {
    open: true,
    port: 3000
  },

  // 有利于开发期间定位错误信息
  devtool: 'eval-source-map',

  module: {
    rules: [
      { test: /\.css$/, use: ['style-loader', 'css-loader'] },
      { test: /\.(sass|scss)$/, use: ['style-loader', 'css-loader', 'sass-loader'] },
      { test: /\.(png|jpg|jpeg|gif)$/, use: 'url-loader' },
      { test: /\.(eot|woff|woff2|ttf|svg|otf)$/, use: 'url-loader' },

      // mui 的路径中包含：lib
      // 将 mui 排除，不经过 babel 的处理，那么，mui的代码就不会运行在 严格模式 中了！
      // 只要经过 babel 处理的js文件，都会默认升级为：严格模式
      { test: /\.js$/, use: 'babel-loader', exclude: /node_modules|lib/ },
      { test: /\.vue$/, use: 'vue-loader' }
    ]
  },

  plugins: [
    new htmlWebpackPlugin({
      template: path.join(__dirname, './src/index.html')
    })
  ]
}