// 1 App() 函数用来注册一个小程序。
// 2 参数是一个对象，对象中包括：生命周期函数 以及 一些全局数据

App({
  // 生命周期函数--监听小程序初始化
  // 特点：当小程序初始化完成时，会触发 onLaunch（全局只触发一次）
  // 可以用来做登录，这样只需要执行一次的操作
  onLaunch: function (options) {
    console.warn('生命周期 - onLaunch', options)
  },

  // 生命周期函数--监听小程序显示
  // 当小程序启动，或从后台进入前台显示，会触发 onShow
  onShow: function (options) {
    console.warn('生命周期 - onShow', options)
  },

  // 生命周期函数--监听小程序隐藏	
  // 当小程序从前台进入后台，会触发 onHide
  onHide: function () {
    console.warn('生命周期 - onHide')
  },

  // 错误监听函数
  onError: function () {
    console.warn('生命周期 - onError')
  },

  // 此处的 globalData 表示全局属性，但是名称不是固定的
  globalData: {
    userInfo: 'jack'
  }
})