// getApp() 方法用来获取全局对象（app对象）
// const app = getApp()
// console.log(app.globalData)

// Page() 函数用来注册一个页面

Page({

  /**
   * 页面的初始数据
   */
  data: {
    msg: 'hello xcx',
    isShow: true,
    list: [
      { id: 1, name: '抽烟' },
      { id: 2, name: '喝酒' },
      { id: 3, name: '烫头发' },
    ],

    arr: [1, 3, 7, 9],

    // 获取用户在文本框中输入的内容
    input: ''
  },

  // 通过这个方法实现“双向数据绑定机制”
  getTextValue(event) {
    // console.log(event.detail.value)
    this.setData({
      input: event.detail.value
    })
  },

  // 获取用户输入的内容，然后添加数据
  addTxt() {
    this.data.list.push({
      id: 4,
      name: this.data.input
    })

    this.setData({
      list: this.data.list
    })
  },

  // 给列表添加数据
  add() {
    this.data.list.unshift({
      id: 4,
      name: '撩猫'
    })

    this.setData({
      list: this.data.list
    })
  },

  // 单击事件
  handleTap() {
    // 获取数据： this.data.数据
    this.data.isShow = !this.data.isShow

    // 将修改后的数据映射到视图(模板)中
    this.setData({
      isShow: this.data.isShow
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.warn('页面生命周期 - onLoad')
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    console.warn('页面生命周期 - onReady')
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    console.warn('页面生命周期 - onShow')
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    console.warn('页面生命周期 - onHide')
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    console.warn('页面生命周期 - onUnload')
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})